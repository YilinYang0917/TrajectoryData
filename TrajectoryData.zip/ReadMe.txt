Videos are recorded with an interval of 0.12 s 
Column 1: ID
Column 2: original time
Column 3: x-coordinate in m
Column 4: y-coordinate in m
Column 5: x-speed in m/s
Column 6: y-speed in m/s
Column 7: x-acceleration in m/s2
Column 8: y-acceleration in m/s2
Column 9: speed in km/h
Column 10: acceleration in m/s2
Column 11: space
Column 12: curvature
Column 13: vehicle type
Column 14: time in s

vehicle type:
1-Moped
2-Bicycle
